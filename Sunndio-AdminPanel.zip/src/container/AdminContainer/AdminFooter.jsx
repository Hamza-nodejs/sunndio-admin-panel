import React from 'react'

const AdminFooter = () => {
  return (
    <>
      <h3>Footer</h3>
    </>
  )
}

export default AdminFooter;
